public class cashier {
	// initialize variables
	double total = 0.0, coupontotal = 0.0; // initialize totals
	double finaltotal; // initialize calculation variables
	
	// CONSTANT VARIABLES
		double PENNIES = .01;
		double NICKELS = .05;
		double DIMES = .1;
		double QUARTERS = .25;
		double DOLLARS = 1;
		double FIVES = 5;
		double TENS = 10;
		double TWENTIES = 20;
		
	public void Scan_Cart(Cart cart) {
		for(int x = 0;x<cart.stuff.size();x++) {
			total = total + cart.stuff.get(x).price; // add item price to total
		}
		
	}
	
	public void Coupon(double coupon) {
		coupontotal = coupontotal + coupon; // add coupon total
	}
	
	public void Receipt() {
	// Display item total, coupon total, subtotal, tax percentage, tax amount and total
	
		System.out.printf("ITEM TOTAL: $%.2f%n", total);
		System.out.printf("\n" + "COUPON TOTAL: $%.2f%n", coupontotal);
		
		double subtotal = total - coupontotal;
		System.out.printf("\n" + "SUBTOTAL: $%.2f%n", subtotal);
		
		double totalwithtax = subtotal * 0.1;
		System.out.printf("\n" + "TAX AMOUNT: $%.2f%n", totalwithtax);
		
		finaltotal = totalwithtax + subtotal;
		System.out.printf("\n" + "TOTAL: $%.2f%n", finaltotal);
				
	}
	
	public void Payment(double cash) {
    // Tell cashier the amount to give back to customer
		double cashowed = cash - finaltotal;
		System.out.printf("\n" + "CHANGE OWED: $%.2f%n", cashowed);
		
		// Display amount of each bill to give back in change
     
		int twenties = (int) Math.floor(cashowed/TWENTIES);
		int tens = (int) Math.floor((cashowed - twenties * TWENTIES)/TENS);
		int fives = (int) Math.floor((cashowed-twenties * TWENTIES - tens * TENS)/FIVES);
		int ones = (int) Math.floor((cashowed - twenties * TWENTIES - tens * TENS - fives * FIVES));
        
		double cashleft = cashowed - twenties * TWENTIES - tens * TENS - fives * FIVES - ones * DOLLARS;
		
		// correct incorrect decimal of .999999
		cashleft = Math.round(cashleft * 100.0) /100.0;
		
		int quarters =  (int) Math.floor(cashleft/.25);
		
        cashleft = cashowed - twenties * TWENTIES - tens * TENS - fives * FIVES - ones * DOLLARS - quarters * QUARTERS;
		
		// correct incorrect decimal of .999999
		cashleft = Math.round(cashleft * 100.0) /100.0;
		
		int dimes =  (int) Math.floor(cashleft/DIMES);
		
		cashleft = cashowed - twenties * TWENTIES - tens * TENS - fives * FIVES - ones * DOLLARS - quarters * QUARTERS - dimes * DIMES;
		
		// correct incorrect decimal of .999999
		cashleft = Math.round(cashleft * 100.0) /100.0;
		
		int nickels =  (int) Math.floor(cashleft/NICKELS);
		cashleft = cashowed - twenties * TWENTIES - tens * TENS - fives * FIVES - ones * DOLLARS - quarters * QUARTERS - dimes * DIMES - nickels * NICKELS;
		
		// correct incorrect decimal of .999999
		cashleft = Math.round(cashleft * 100.0) /100.0;
		
		int pennies =  (int) Math.floor(cashleft/PENNIES);
		
		// Print correct change to give back	
		if (twenties > 0)
		{
			System.out.print("$20.00: " + twenties + "\n");
		}
			
		if (tens > 0)
		{
			System.out.print("$10.00: " + tens + "\n");
		}
			
		if (fives > 0)
		{
			System.out.print("$5.00: " + fives + "\n");
		}	
		
		if (ones > 0)
		{
			System.out.print("$1.00: " + ones + "\n");
		}	
		
		if (quarters > 0)
		{
			System.out.print("$0.25: " + quarters + "\n");
		}	
			
		if (dimes > 0)
		{
			System.out.print("$0.10: " + dimes + "\n");
		}
			
		if (nickels > 0)
		{
			System.out.print("$0.05: " + nickels + "\n");
		}
			
		if (pennies > 0)
		{
			System.out.print("$0.01: " + pennies + "\n");
		}
	}
}
