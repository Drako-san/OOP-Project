public class Items { // for the name, price, and amount of items
	String name;
	double price;
	int amount;
	public Items(String n, double p, int a) {
		name = n;
		price = p;
		amount = a;
	}
}
