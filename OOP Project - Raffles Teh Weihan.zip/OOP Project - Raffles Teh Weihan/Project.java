import java.util.Scanner;
import java.lang.Math;
public class Project extends cashier  {
	public static void main(String[] args) {
		Cart c = new Cart(); // To instantiate Cart
		cashier Jeff = new cashier(); // To instantiate cashier
		Scanner input = new Scanner(System.in); // For inputing
		boolean exit = false; //Looping menu
		while(!exit) {
			int choice = menu(input);
			switch(choice) {
			case 1: //Putting items in to the cart
				System.out.print("Enter item name:");
				String n = input.next();
				System.out.print("Enter item price:");
				double p = input.nextDouble();
				System.out.print("Enter amount of items:");
				int a = input.nextInt();
				c.stuff.add(new Items(n,p*a,a)); //putting items in carts
				System.out.println("");
				break;
			case 2: //To run the cashier 
				Jeff.Scan_Cart(c);
				double coupon = 1;
				while(coupon != 0) { //Looping the coupon entered
					System.out.print("Enter Coupon or 0 to quit: ");
					coupon = input.nextDouble();
					Jeff.Coupon(coupon);
				}
				Jeff.Receipt();//Displays the receipt
				System.out.print("\n" + "Enter amount of cash given: ");
				double cash = input.nextDouble();
				Jeff.Payment(cash);
				System.out.println("");
				break;
			case 3: //To exit the program
				System.out.println("----------------------");
				System.out.println("***END OF PROGRAM***");
				exit = true;
				break;
			default: //If they chose anything either than the options
				System.out.println("\nTry again\n");
				break;
			}
		}
	}
	// The menu
	public static int menu(Scanner input) {
		System.out.println("Welcome to le store");
		System.out.println("-------------------------");
		System.out.println("Please make a selection:");
		System.out.println("1. Add item to cart");
		System.out.println("2. Go to cashier");
		System.out.println("3. Exit Program\n");
		System.out.print("Enter Input:");
		int choice = input.nextInt();
		return choice;
	}
	
}
