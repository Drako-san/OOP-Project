import java.util.ArrayList;
public class Cart {
	ArrayList<Items> stuff = new ArrayList<Items>(); //Cart to store items
}
